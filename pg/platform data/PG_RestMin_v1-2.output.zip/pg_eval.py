import numpy as np
import torch as th

from sb3_contrib.common.wrappers import ActionMasker
from stable_baselines3.common.utils import obs_as_tensor

from env import RestMinEnv_v1
from pg import PolicyGradient


def mask_fn(env):
    return env.get_action_mask()

if __name__ == "__main__":
    env = RestMinEnv_v1(size=6, mode=1)
    env = ActionMasker(env, mask_fn)
    model = PolicyGradient.load(path="pg", env=env, device="cpu")
    
    obs = env.reset()
    while True:
        print(env.state["obs"], "\n")
        action, _ = model.predict(obs_as_tensor(obs, "cpu"), action_masks=env.get_action_mask())
        obs, reward, done, info = env.step(action)
        if done:
            break
    

